﻿namespace EjercicioGepeto.Models.ENT
{
    public class ClsPersona
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
        public int IdDep { get; set; }
    }
}

﻿namespace EjercicioGepeto.Models.ENT
{
    public class ClsDepartamento
    {
        public int IdDep { get; set; }
        public string Nombre { get; set; }
    }
}
